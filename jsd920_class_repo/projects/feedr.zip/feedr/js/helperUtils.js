var models = {};

models.hello = function(word) {
  console.log("Hello", word)
}
