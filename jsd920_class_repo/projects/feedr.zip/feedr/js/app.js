/*
  Please add all Javascript code to this file.
*/


 $.get("https://accesscontrolalloworiginall.herokuapp.com/http://mashable.com/stories.json", function(response) {
 	var results = response.new;
 	var articles = parseResults(results);
 	console.log(articles);
});

function parseResults(results){
	var all_articles = []; //this is a placeholder for what we want to return
	results.forEach(function(row){
		var article = {
			title : row.title,
			image : row.image,
			link : row.link,
			channel : row.channel,
			shares : row.shares.total,
			content : row.content.plain
		};
		all_articles.push(article); //we want to push the object in to the all articles array
	});

	return all_articles;
}

function addArticlesToPage(articles) {

}

function addSingleArticleToPage() {  //add the items to the dom jquery - or handlebars 

}

//do not use, just for demo!!

// function Article(row){  //object constructor
// 	this.title =  row.title;
// 	this.image = row.image;
// 	this.link = row.link;
// 	this.channel = row.channel;
// 	this.shares = row.shares.total;
// 	this.content = row.content.plain;
// };


